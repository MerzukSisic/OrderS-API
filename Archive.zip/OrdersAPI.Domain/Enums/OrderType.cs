﻿namespace OrdersAPI.Domain.Enums;

public enum OrderType
{
    DineIn,
    TakeAway
}

﻿namespace OrdersAPI.Domain.Enums;

public enum NotificationType
{
    Info,
    Warning,
    Error,
    LowStock
}

﻿namespace OrdersAPI.Domain.Enums;

public enum UserRole
{
    Admin,
    Waiter,
    Bartender
}

﻿namespace OrdersAPI.Domain.Enums;

public enum PreparationLocation
{
    Kitchen,
    Bar
}

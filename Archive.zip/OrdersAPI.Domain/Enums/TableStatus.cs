﻿namespace OrdersAPI.Domain.Enums;

public enum TableStatus
{
    Available,
    Occupied,
    Reserved
}

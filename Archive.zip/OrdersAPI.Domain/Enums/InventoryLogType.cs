﻿namespace OrdersAPI.Domain.Enums;

public enum InventoryLogType
{
    Sale,
    Restock,
    Adjustment,
    Damage
}

﻿using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using OrdersAPI.Application.DTOs;
using OrdersAPI.Application.Interfaces;
using Stripe;

namespace OrdersAPI.Infrastructure.Services;

public class StripeService : IStripeService
{
    private readonly IConfiguration _configuration;
    private readonly ILogger<StripeService> _logger;
    private readonly string _webhookSecret;

    public StripeService(IConfiguration configuration, ILogger<StripeService> logger)
    {
        _configuration = configuration;
        _logger = logger;
        
        // Set API key once
        StripeConfiguration.ApiKey = _configuration["Stripe:SecretKey"];
        _webhookSecret = _configuration["Stripe:WebhookSecret"] ?? string.Empty;
    }

    public async Task<PaymentIntentResponseDto> CreatePaymentIntentAsync(CreatePaymentIntentDto dto)
    {
        try
        {
            // Convert KM to EUR if needed (Stripe doesn't support BAM directly)
            var (amount, currency) = ConvertCurrency(dto.Amount, dto.Currency);

            var options = new PaymentIntentCreateOptions
            {
                Amount = (long)(amount * 100), // Convert to cents
                Currency = currency,
                PaymentMethodTypes = new List<string> { "card" },
                Metadata = new Dictionary<string, string>
                {
                    { "orderId", dto.OrderId.ToString() },
                    { "tableNumber", dto.TableNumber ?? "N/A" },
                    { "originalAmount", dto.Amount.ToString("F2") },
                    { "originalCurrency", dto.Currency.ToUpper() }
                },
                Description = $"Order #{dto.OrderId.ToString().Substring(0, 8)} - Table {dto.TableNumber}",
                ReceiptEmail = dto.CustomerEmail
            };

            // Add customer info if provided
            if (!string.IsNullOrEmpty(dto.CustomerEmail))
            {
                options.ReceiptEmail = dto.CustomerEmail;
            }

            var service = new PaymentIntentService();
            var paymentIntent = await service.CreateAsync(options);

            _logger.LogInformation("Payment intent created: {PaymentIntentId} for order {OrderId}, amount {Amount} {Currency}",
                paymentIntent.Id, dto.OrderId, dto.Amount, dto.Currency.ToUpper());

            return new PaymentIntentResponseDto
            {
                PaymentIntentId = paymentIntent.Id,
                ClientSecret = paymentIntent.ClientSecret,
                Amount = dto.Amount,
                Currency = dto.Currency,
                Status = paymentIntent.Status
            };
        }
        catch (StripeException ex)
        {
            _logger.LogError(ex, "Stripe error creating payment intent for order {OrderId}", dto.OrderId);
            throw new InvalidOperationException($"Payment processing error: {ex.StripeError.Message}", ex);
        }
    }

    public async Task<PaymentIntentResponseDto> GetPaymentIntentAsync(string paymentIntentId)
    {
        try
        {
            var service = new PaymentIntentService();
            var paymentIntent = await service.GetAsync(paymentIntentId);

            // Extract original amount from metadata if exists
            var originalAmount = paymentIntent.Metadata.TryGetValue("originalAmount", out var amtStr) 
                ? decimal.Parse(amtStr) 
                : paymentIntent.Amount / 100m;

            var originalCurrency = paymentIntent.Metadata.TryGetValue("originalCurrency", out var curr) 
                ? curr.ToLower() 
                : paymentIntent.Currency;

            return new PaymentIntentResponseDto
            {
                PaymentIntentId = paymentIntent.Id,
                ClientSecret = paymentIntent.ClientSecret,
                Amount = originalAmount,
                Currency = originalCurrency,
                Status = paymentIntent.Status
            };
        }
        catch (StripeException ex)
        {
            _logger.LogError(ex, "Error retrieving payment intent {PaymentIntentId}", paymentIntentId);
            throw new InvalidOperationException($"Error retrieving payment: {ex.StripeError.Message}", ex);
        }
    }

    public async Task<bool> ConfirmPaymentAsync(string paymentIntentId)
    {
        try
        {
            var service = new PaymentIntentService();
            var paymentIntent = await service.GetAsync(paymentIntentId);

            var isSuccessful = paymentIntent.Status == "succeeded";

            _logger.LogInformation("Payment intent {PaymentIntentId} status: {Status}", 
                paymentIntentId, paymentIntent.Status);

            return isSuccessful;
        }
        catch (StripeException ex)
        {
            _logger.LogError(ex, "Error confirming payment {PaymentIntentId}", paymentIntentId);
            return false;
        }
    }

    public async Task<bool> CancelPaymentIntentAsync(string paymentIntentId)
    {
        try
        {
            var service = new PaymentIntentService();
            var paymentIntent = await service.CancelAsync(paymentIntentId);

            _logger.LogInformation("Payment intent {PaymentIntentId} cancelled", paymentIntentId);

            return paymentIntent.Status == "canceled";
        }
        catch (StripeException ex)
        {
            _logger.LogError(ex, "Error cancelling payment intent {PaymentIntentId}", paymentIntentId);
            throw new InvalidOperationException($"Error cancelling payment: {ex.StripeError.Message}", ex);
        }
    }

    public async Task<RefundResponseDto> RefundPaymentAsync(RefundRequestDto dto)
    {
        try
        {
            var options = new RefundCreateOptions
            {
                PaymentIntent = dto.PaymentIntentId,
                Reason = dto.Reason
            };

            // Partial refund if amount specified
            if (dto.Amount.HasValue)
            {
                options.Amount = (long)(dto.Amount.Value * 100);
            }

            var service = new RefundService();
            var refund = await service.CreateAsync(options);

            _logger.LogInformation("Refund created: {RefundId} for payment intent {PaymentIntentId}, amount {Amount}",
                refund.Id, dto.PaymentIntentId, refund.Amount / 100m);

            return new RefundResponseDto
            {
                RefundId = refund.Id,
                Amount = refund.Amount / 100m,
                Status = refund.Status,
                Reason = refund.Reason ?? "N/A"
            };
        }
        catch (StripeException ex)
        {
            _logger.LogError(ex, "Error creating refund for payment intent {PaymentIntentId}", dto.PaymentIntentId);
            throw new InvalidOperationException($"Refund error: {ex.StripeError.Message}", ex);
        }
    }

    public async Task<RefundResponseDto> GetRefundAsync(string refundId)
    {
        try
        {
            var service = new RefundService();
            var refund = await service.GetAsync(refundId);

            return new RefundResponseDto
            {
                RefundId = refund.Id,
                Amount = refund.Amount / 100m,
                Status = refund.Status,
                Reason = refund.Reason ?? "N/A"
            };
        }
        catch (StripeException ex)
        {
            _logger.LogError(ex, "Error retrieving refund {RefundId}", refundId);
            throw new InvalidOperationException($"Error retrieving refund: {ex.StripeError.Message}", ex);
        }
    }

    public async Task<WebhookEventDto> HandleWebhookAsync(string json, string signature)
    {
        try
        {
            var stripeEvent = EventUtility.ConstructEvent(
                json,
                signature,
                _webhookSecret
            );

            _logger.LogInformation("Webhook received: {EventType} - {EventId}", 
                stripeEvent.Type, stripeEvent.Id);

            // ✅ Use string literals instead of Events class
            switch (stripeEvent.Type)
            {
                case "payment_intent.succeeded":
                {
                    var paymentIntent = stripeEvent.Data.Object as PaymentIntent;
                    if (paymentIntent != null)
                    {
                        _logger.LogInformation("Payment succeeded: {PaymentIntentId}", paymentIntent.Id);
                        
                        return new WebhookEventDto
                        {
                            EventId = stripeEvent.Id,
                            EventType = stripeEvent.Type,
                            PaymentIntentId = paymentIntent.Id,
                            Status = paymentIntent.Status,
                            Amount = paymentIntent.Amount / 100m
                        };
                    }
                    break;
                }

                case "payment_intent.payment_failed":
                {
                    var paymentIntent = stripeEvent.Data.Object as PaymentIntent;
                    if (paymentIntent != null)
                    {
                        _logger.LogWarning("Payment failed for intent {PaymentIntentId}", paymentIntent.Id);
                        
                        return new WebhookEventDto
                        {
                            EventId = stripeEvent.Id,
                            EventType = stripeEvent.Type,
                            PaymentIntentId = paymentIntent.Id,
                            Status = paymentIntent.Status,
                            Amount = paymentIntent.Amount / 100m
                        };
                    }
                    break;
                }

                case "charge.refunded":
                {
                    var charge = stripeEvent.Data.Object as Charge;
                    if (charge != null)
                    {
                        _logger.LogInformation("Charge refunded: {ChargeId}", charge.Id);
                        
                        return new WebhookEventDto
                        {
                            EventId = stripeEvent.Id,
                            EventType = stripeEvent.Type,
                            PaymentIntentId = charge.PaymentIntentId ?? string.Empty,
                            Status = "refunded",
                            Amount = charge.AmountRefunded / 100m
                        };
                    }
                    break;
                }
            }

            // Unhandled event type
            _logger.LogInformation("Unhandled webhook event type: {EventType}", stripeEvent.Type);
            
            return new WebhookEventDto
            {
                EventId = stripeEvent.Id,
                EventType = stripeEvent.Type,
                PaymentIntentId = string.Empty,
                Status = "unhandled",
                Amount = 0
            };
        }
        catch (StripeException ex)
        {
            _logger.LogError(ex, "Webhook signature verification failed");
            throw new UnauthorizedAccessException("Invalid webhook signature", ex);
        }
    }

    // ========== PRIVATE HELPER METHODS ==========

    private static (decimal amount, string currency) ConvertCurrency(decimal amount, string currency)
    {
        // Stripe doesn't support BAM (Bosnian Mark) directly
        // Convert BAM/KM to EUR (approximate rate: 1 EUR = 1.95583 BAM)
        if (currency.ToUpper() is "BAM" or "KM")
        {
            const decimal BAM_TO_EUR = 0.51129m; // 1 BAM = 0.51129 EUR
            var eurAmount = Math.Round(amount * BAM_TO_EUR, 2);
            return (eurAmount, "eur");
        }

        return (amount, currency.ToLower());
    }
}

﻿using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Logging;
using OrdersAPI.Application.DTOs;
using OrdersAPI.Application.Interfaces;
using OrdersAPI.Domain.Entities;
using OrdersAPI.Domain.Enums;
using OrdersAPI.Infrastructure.Data;

namespace OrdersAPI.Infrastructure.Services;

public class ProcurementService(
    ApplicationDbContext context,
    ILogger<ProcurementService> logger)
    : IProcurementService
{
    public async Task<IEnumerable<ProcurementOrderDto>> GetAllProcurementOrdersAsync(Guid? storeId = null)
    {
        var query = context.ProcurementOrders
            .AsNoTracking()
            .Include(p => p.Store)
            .Include(p => p.Items)
                .ThenInclude(i => i.StoreProduct)
            .AsQueryable();

        if (storeId.HasValue)
            query = query.Where(p => p.StoreId == storeId);

        var orders = await query
            .OrderByDescending(p => p.OrderDate)
            .Select(p => new ProcurementOrderDto
            {
                Id = p.Id,
                StoreId = p.StoreId,
                StoreName = p.Store.Name,
                Supplier = p.Supplier,
                TotalAmount = p.TotalAmount,
                Status = p.Status.ToString(),
                StripePaymentIntentId = p.StripePaymentIntentId,
                Notes = p.Notes,
                OrderDate = p.OrderDate,
                DeliveryDate = p.DeliveryDate,
                Items = p.Items.Select(i => new ProcurementOrderItemDto
                {
                    Id = i.Id,
                    StoreProductId = i.StoreProductId,
                    StoreProductName = i.StoreProduct.Name,
                    Quantity = i.Quantity,
                    UnitCost = i.UnitCost,
                    Subtotal = i.Subtotal
                }).ToList()
            })
            .ToListAsync();

        return orders;
    }

    public async Task<ProcurementOrderDto> GetProcurementOrderByIdAsync(Guid id)
    {
        var order = await context.ProcurementOrders
            .AsNoTracking()
            .Include(p => p.Store)
            .Include(p => p.Items)
                .ThenInclude(i => i.StoreProduct)
            .Select(p => new ProcurementOrderDto
            {
                Id = p.Id,
                StoreId = p.StoreId,
                StoreName = p.Store.Name,
                Supplier = p.Supplier,
                TotalAmount = p.TotalAmount,
                Status = p.Status.ToString(),
                StripePaymentIntentId = p.StripePaymentIntentId,
                Notes = p.Notes,
                OrderDate = p.OrderDate,
                DeliveryDate = p.DeliveryDate,
                Items = p.Items.Select(i => new ProcurementOrderItemDto
                {
                    Id = i.Id,
                    StoreProductId = i.StoreProductId,
                    StoreProductName = i.StoreProduct.Name,
                    Quantity = i.Quantity,
                    UnitCost = i.UnitCost,
                    Subtotal = i.Subtotal
                }).ToList()
            })
            .FirstOrDefaultAsync(p => p.Id == id);

        if (order == null)
            throw new KeyNotFoundException($"Procurement order with ID {id} not found");

        return order;
    }

    public async Task<ProcurementOrderDto> CreateProcurementOrderAsync(CreateProcurementDto dto)
    {
        var storeExists = await context.Stores.AnyAsync(s => s.Id == dto.StoreId);
        if (!storeExists)
            throw new KeyNotFoundException($"Store with ID {dto.StoreId} not found");

        var procurement = new ProcurementOrder
        {
            Id = Guid.NewGuid(),
            StoreId = dto.StoreId,
            Supplier = dto.Supplier,
            Status = ProcurementStatus.Pending,
            OrderDate = DateTime.UtcNow,
            Notes = dto.Notes
        };

        decimal totalAmount = 0;

        foreach (var itemDto in dto.Items)
        {
            var storeProduct = await context.StoreProducts.FindAsync(itemDto.StoreProductId);
            if (storeProduct == null)
                throw new KeyNotFoundException($"Store product with ID {itemDto.StoreProductId} not found");

            var subtotal = storeProduct.PurchasePrice * itemDto.Quantity;
            totalAmount += subtotal;

            procurement.Items.Add(new ProcurementOrderItem
            {
                Id = Guid.NewGuid(),
                StoreProductId = itemDto.StoreProductId,
                Quantity = itemDto.Quantity,
                UnitCost = storeProduct.PurchasePrice,
                Subtotal = subtotal
            });
        }

        procurement.TotalAmount = totalAmount;
        context.ProcurementOrders.Add(procurement);
        await context.SaveChangesAsync();

        logger.LogInformation("Procurement order {OrderId} created for store {StoreId} with {ItemCount} items", 
            procurement.Id, dto.StoreId, procurement.Items.Count);

        return await GetProcurementOrderByIdAsync(procurement.Id);
    }

    public async Task<string> CreatePaymentIntentAsync(Guid procurementOrderId)
    {
        var order = await context.ProcurementOrders.FindAsync(procurementOrderId);
        if (order == null)
            throw new KeyNotFoundException($"Procurement order with ID {procurementOrderId} not found");

        // ⚠️ STUB - Za development bez Stripe-a
        // U produkciji integriši Stripe Payment Intent
        var clientSecret = $"pi_stub_{Guid.NewGuid()}";

        logger.LogInformation("Payment intent stub created for procurement order {OrderId}", procurementOrderId);

        return clientSecret;
    }

    public async Task ConfirmPaymentAsync(Guid procurementOrderId, string paymentIntentId)
    {
        var order = await context.ProcurementOrders
            .Include(p => p.Items)
                .ThenInclude(i => i.StoreProduct)
            .FirstOrDefaultAsync(p => p.Id == procurementOrderId);

        if (order == null)
            throw new KeyNotFoundException($"Procurement order with ID {procurementOrderId} not found");

        // ⚠️ STUB - Za development bez Stripe-a
        // U produkciji provjeri Stripe Payment Intent status
        var paymentSucceeded = true;

        if (!paymentSucceeded)
            throw new InvalidOperationException("Payment failed");

        order.Status = ProcurementStatus.Paid;
        order.StripePaymentIntentId = paymentIntentId;

        // Ne update-uj stock dok ne dođe roba (Paid !== Received)
        await context.SaveChangesAsync();

        logger.LogInformation("Procurement order {OrderId} marked as paid", procurementOrderId);
    }

    public async Task UpdateProcurementStatusAsync(Guid id, ProcurementStatus status)
    {
        var order = await context.ProcurementOrders.FindAsync(id);
        if (order == null)
            throw new KeyNotFoundException($"Procurement order with ID {id} not found");

        order.Status = status;

        if (status == ProcurementStatus.Received)
            order.DeliveryDate = DateTime.UtcNow;

        await context.SaveChangesAsync();

        logger.LogInformation("Procurement order {OrderId} status updated to {Status}", id, status);
    }

    public async Task ReceiveProcurementAsync(Guid procurementOrderId, ReceiveProcurementDto dto)
    {
        var order = await context.ProcurementOrders
            .Include(p => p.Items)
                .ThenInclude(i => i.StoreProduct)
            .FirstOrDefaultAsync(p => p.Id == procurementOrderId);

        if (order == null)
            throw new KeyNotFoundException($"Procurement order with ID {procurementOrderId} not found");

        if (order.Status != ProcurementStatus.Paid)
            throw new InvalidOperationException("Order must be paid before receiving");

        foreach (var receivedItem in dto.Items)
        {
            var orderItem = order.Items.FirstOrDefault(i => i.Id == receivedItem.ItemId);
            if (orderItem == null)
                throw new KeyNotFoundException($"Order item with ID {receivedItem.ItemId} not found");

            if (receivedItem.ReceivedQuantity > orderItem.Quantity)
                throw new InvalidOperationException(
                    $"Received quantity ({receivedItem.ReceivedQuantity}) cannot exceed ordered quantity ({orderItem.Quantity})"
                );

            // Update stock
            orderItem.StoreProduct.CurrentStock += receivedItem.ReceivedQuantity;
            orderItem.StoreProduct.LastRestocked = DateTime.UtcNow;

            // Log inventory change
            context.InventoryLogs.Add(new InventoryLog
            {
                Id = Guid.NewGuid(),
                StoreProductId = orderItem.StoreProductId,
                QuantityChange = receivedItem.ReceivedQuantity,
                Type = InventoryLogType.Restock,
                Reason = $"Procurement Order {order.Id} - Received {receivedItem.ReceivedQuantity}/{orderItem.Quantity}",
                CreatedAt = DateTime.UtcNow
            });

            logger.LogInformation("Received {ReceivedQty}/{OrderedQty} of {ProductName} for procurement {OrderId}",
                receivedItem.ReceivedQuantity, orderItem.Quantity, orderItem.StoreProduct.Name, procurementOrderId);
        }

        // Update order status
        order.Status = ProcurementStatus.Received;
        order.DeliveryDate = DateTime.UtcNow;
        if (!string.IsNullOrEmpty(dto.Notes))
            order.Notes = $"{order.Notes}\n[RECEIVED: {dto.Notes}]";

        await context.SaveChangesAsync();

        logger.LogInformation("Procurement order {OrderId} fully received and inventory updated", procurementOrderId);
    }
}

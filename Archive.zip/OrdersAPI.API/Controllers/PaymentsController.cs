using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using OrdersAPI.Application.DTOs;
using OrdersAPI.Application.Interfaces;

namespace OrdersAPI.API.Controllers;

[ApiController]
[Route("api/[controller]")]
[Authorize]
public class PaymentsController(IStripeService stripeService) : ControllerBase
{
    [HttpPost("create-intent")]
    public async Task<ActionResult<PaymentIntentResponseDto>> CreatePaymentIntent(
        [FromBody] CreatePaymentIntentDto dto)
    {
        var response = await stripeService.CreatePaymentIntentAsync(dto);
        return Ok(response);
    }

    [HttpGet("intent/{paymentIntentId}")]
    public async Task<ActionResult<PaymentIntentResponseDto>> GetPaymentIntent(string paymentIntentId)
    {
        var response = await stripeService.GetPaymentIntentAsync(paymentIntentId);
        return Ok(response);
    }

    [HttpPost("confirm/{paymentIntentId}")]
    public async Task<ActionResult<bool>> ConfirmPayment(string paymentIntentId)
    {
        var isConfirmed = await stripeService.ConfirmPaymentAsync(paymentIntentId);
        return Ok(new { confirmed = isConfirmed });
    }

    [HttpPost("cancel/{paymentIntentId}")]
    public async Task<ActionResult<bool>> CancelPayment(string paymentIntentId)
    {
        var isCancelled = await stripeService.CancelPaymentIntentAsync(paymentIntentId);
        return Ok(new { cancelled = isCancelled });
    }

    [HttpPost("refund")]
    [Authorize(Roles = "Admin")]
    public async Task<ActionResult<RefundResponseDto>> RefundPayment([FromBody] RefundRequestDto dto)
    {
        var response = await stripeService.RefundPaymentAsync(dto);
        return Ok(response);
    }

    [HttpGet("refund/{refundId}")]
    public async Task<ActionResult<RefundResponseDto>> GetRefund(string refundId)
    {
        var response = await stripeService.GetRefundAsync(refundId);
        return Ok(response);
    }

    [HttpPost("webhook")]
    [AllowAnonymous]
    public async Task<IActionResult> HandleWebhook()
    {
        var json = await new StreamReader(HttpContext.Request.Body).ReadToEndAsync();
        var signature = Request.Headers["Stripe-Signature"].ToString();

        var eventDto = await stripeService.HandleWebhookAsync(json, signature);

        // TODO: Update order status based on webhook event
        // Example: if eventDto.EventType == "payment_intent.succeeded"
        //          → update order.PaymentStatus = "Paid"

        return Ok();
    }
}

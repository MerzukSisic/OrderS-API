﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using OrdersAPI.Application.DTOs;
using OrdersAPI.Application.Interfaces;
using OrdersAPI.Domain.Entities;
using OrdersAPI.Domain.Enums;

namespace OrdersAPI.API.Controllers;

[ApiController]
[Route("api/[controller]")]
[Authorize(Roles = "Admin")]
public class ProcurementController(IProcurementService procurementService) : ControllerBase
{
    [HttpGet]
    public async Task<ActionResult<IEnumerable<ProcurementOrderDto>>> GetProcurementOrders([FromQuery] Guid? storeId = null)
    {
        var orders = await procurementService.GetAllProcurementOrdersAsync(storeId);
        return Ok(orders);
    }

    [HttpGet("{id}")]
    public async Task<ActionResult<ProcurementOrderDto>> GetProcurementOrder(Guid id)
    {
        var order = await procurementService.GetProcurementOrderByIdAsync(id);
        return Ok(order);
    }

    [HttpPost]
    public async Task<ActionResult<ProcurementOrderDto>> CreateProcurementOrder([FromBody] CreateProcurementDto dto)
    {
        var order = await procurementService.CreateProcurementOrderAsync(dto);
        return CreatedAtAction(nameof(GetProcurementOrder), new { id = order.Id }, order);
    }

    [HttpPost("{id}/payment-intent")]
    public async Task<ActionResult<PaymentIntentDto>> CreatePaymentIntent(Guid id)
    {
        var clientSecret = await procurementService.CreatePaymentIntentAsync(id);
        return Ok(new PaymentIntentDto { ClientSecret = clientSecret });
    }

    [HttpPost("{id}/confirm-payment")]
    public async Task<IActionResult> ConfirmPayment(Guid id, [FromBody] ConfirmPaymentDto dto)
    {
        await procurementService.ConfirmPaymentAsync(id, dto.PaymentIntentId);
        return NoContent();
    }

    [HttpPut("{id}/status")]
    public async Task<IActionResult> UpdateStatus(Guid id, [FromQuery] string status)
    {
        var procurementStatus = Enum.Parse<ProcurementStatus>(status);
        await procurementService.UpdateProcurementStatusAsync(id, procurementStatus);
        return NoContent();
    }

    [HttpPost("{id}/receive")]
    public async Task<IActionResult> ReceiveProcurement(Guid id, [FromBody] ReceiveProcurementDto dto)
    {
        await procurementService.ReceiveProcurementAsync(id, dto);
        return NoContent();
    }
}

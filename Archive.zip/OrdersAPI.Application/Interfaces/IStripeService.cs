﻿using OrdersAPI.Application.DTOs;

namespace OrdersAPI.Application.Interfaces;

public interface IStripeService
{
    Task<PaymentIntentResponseDto> CreatePaymentIntentAsync(CreatePaymentIntentDto dto);
    Task<PaymentIntentResponseDto> GetPaymentIntentAsync(string paymentIntentId);
    Task<bool> ConfirmPaymentAsync(string paymentIntentId);
    Task<bool> CancelPaymentIntentAsync(string paymentIntentId);
    
    Task<RefundResponseDto> RefundPaymentAsync(RefundRequestDto dto);
    Task<RefundResponseDto> GetRefundAsync(string refundId);
    
    Task<WebhookEventDto> HandleWebhookAsync(string json, string signature);
}
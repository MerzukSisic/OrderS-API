﻿namespace OrdersAPI.Domain.Entities;

public enum NotificationType
{
    Info,
    Warning,
    Error,
    LowStock
}

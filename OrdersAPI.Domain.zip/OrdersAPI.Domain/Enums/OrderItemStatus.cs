﻿namespace OrdersAPI.Domain.Entities;

public enum OrderItemStatus
{
    Pending,
    Preparing,
    Ready
}

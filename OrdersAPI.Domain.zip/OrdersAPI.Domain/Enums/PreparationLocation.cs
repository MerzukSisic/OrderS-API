﻿namespace OrdersAPI.Domain.Entities;

public enum PreparationLocation
{
    Kitchen,
    Bar
}

﻿namespace OrdersAPI.Domain.Entities;

public enum UserRole
{
    Admin,
    Waiter,
    Bartender
}

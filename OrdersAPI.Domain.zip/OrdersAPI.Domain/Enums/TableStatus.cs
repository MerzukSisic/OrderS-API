﻿namespace OrdersAPI.Domain.Entities;

public enum TableStatus
{
    Available,
    Occupied,
    Reserved
}

﻿namespace OrdersAPI.Domain.Entities;

public enum InventoryLogType
{
    Sale,
    Restock,
    Adjustment,
    Damage
}

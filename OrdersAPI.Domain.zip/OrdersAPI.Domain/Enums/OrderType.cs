﻿namespace OrdersAPI.Domain.Entities;

public enum OrderType
{
    DineIn,
    TakeAway
}
